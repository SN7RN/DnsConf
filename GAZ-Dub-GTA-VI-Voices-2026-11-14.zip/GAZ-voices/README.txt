GAZ Dub — демонстрационные русские голоса

Откройте «Сравнить голоса.html» или index.html двойным щелчком.
Люсия: Supertonic F1/F2/F3. Джейсон: Supertonic M1/M2/M3.
Это кандидаты для прослушивания, сходство с оригинальными актёрами не подтверждено.

Шесть WAV сгенерированы локально Supertonic 3 через существующий backend LiveDub.
Фраза написана для теста. Оригинальные записи Rockstar, чужая речь и веса моделей
в этой папке отсутствуют. На пике применяется только уменьшающий gain.

Технические условия и реальные времена — manifest.json; это полный синтез CPU,
а не задержка игры. Значения не распространяются на Windows/RTX 5080.
Исходник генератора: tools/gaz_voice_compare.py, GPL-3.0-or-later, как LiveDub.
SDK Supertonic: MIT. Модель: BigScience Open RAIL-M:
https://huggingface.co/Supertone/supertonic-3/blob/main/LICENSE
Эта ссылка относится к модели; не следует объявлять веса MIT.

Для повторения: python -m tools.gaz_voice_compare --model-dir models/supertonic3
Команда для разработчика; готовые WAV/галерея не требуют Python или сервера.
